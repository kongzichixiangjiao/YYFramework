//
//  GAFullScreenPlayerViewController.swift
//  YYFramework
//
//  Created by houjianan on 2019/12/11.
//  Copyright © 2019 houjianan. All rights reserved.
//

/*
 if state == .full {
 let vc = GAFullScreenPlayerViewController()
 vc.targetView = player
 self.present(vc, animated: true, completion: nil)
 } else {
 self.dismiss(animated: false) {
 self.px_banner.reloadCellView()
 }
 }
 */
import UIKit

class GAFullScreenPlayerViewController: GANavViewController {
    
    private let kOrientation: String = "orientation"
    
    var targetView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        targetView.frame = self.view.bounds
        view.addSubview(targetView)
    }
    
    deinit {
        print("GAFullScreenPlayerViewController")
    }
}

extension GAFullScreenPlayerViewController {
    // 运行页面随设备转动
    override var shouldAutorotate : Bool {
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            //允许横屏
            appDelegate.ga_mandatoryLandscape = true
            
            // 强制横屏打开下面两行代码即可
            //let value = UIInterfaceOrientation.landscapeRight.rawValue
            //UIDevice.current.setValue(value, forKey: "orientation")
            
        }
        
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            //禁止横屏
            appDelegate.ga_mandatoryLandscape = false
        }
        //强制为竖屏
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        
        super.viewWillDisappear(animated)
    }
    
    //下面方法是处理navgation相关的逻辑，如果控制器没有nav，省略
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        coordinator.animate(alongsideTransition: { [weak self] (context) in
            let orient = UIApplication.shared.statusBarOrientation
            switch orient {
            case .landscapeLeft, .landscapeRight:
                //横屏时禁止左拽滑出
                self?.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
                self?.navigationController?.setNavigationBarHidden(true, animated: false)
            default:
                //竖屏时允许左拽滑出
                self?.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
                self?.navigationController?.setNavigationBarHidden(false, animated: false)
            }
        })
        super.viewWillTransition(to: size, with: coordinator)
    }
}
