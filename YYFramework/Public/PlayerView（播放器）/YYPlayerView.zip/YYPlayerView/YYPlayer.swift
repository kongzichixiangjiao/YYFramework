//
//  YYPlayer.swift
//  YYPlayer
//
//  Created by 侯佳男 on 2018/5/2.
//  Copyright © 2018年 侯佳男. All rights reserved.
//

import Foundation
import MediaPlayer

open class YYPlayer: NSObject {
    
    // 监听四种keyPath
    private let kPath_status = "status"
    private let kPath_loadedTimeRanges = "loadedTimeRanges"
    private let kPath_playbackBufferEmpty = "playbackBufferEmpty"
    private let kPath_playbackLikelyToKeepUp = "playbackLikelyToKeepUp"
    
    // 实时播放的闭包
    public typealias DisplayLinkHandler = (_ currentTime: CMTime, _ catchTime: CMTime?, _ state: YYPlayerState) -> ()
    // 播放内容的单例
    public typealias PlayerInfo = (_ totalTime: CMTime, _ state: AVPlayerItem.Status) -> ()
    // 播放完成的单例
    public typealias PlayFinished = () -> ()
    
    public var displayLinkHandler: DisplayLinkHandler!
    public var playerInfo: PlayerInfo!
    public var playFinished: PlayFinished!
    
    var displayLink: CADisplayLink! // 实时刷新progress
    var cacheTime: CMTime? // 缓存时间
    var playerInfoState: AVPlayerItem.Status = .unknown
    
    var isAddObserver: Bool = false
    
    override init() {
        super.init()
    }
    
    // url
    public var url: URL? {
        didSet {
            _addObserver()
            _addNotificationCenter()
            
            _initNewPlayer()
        }
    }
//    let item = AVPlayerItem(url: url)
//    item.preferredForwardBufferDuration = 10
//    self.item = item
//    player.replaceCurrentItem(with: item)
//    itemObserver.item = item
//    itemObserver.player = player
//    layerView.play()
//    state = .loading
    
    func _initNewPlayer() {
        player.replaceCurrentItem(with: playerItem)
    }
    
    public lazy var playerLayer: AVPlayerLayer = {
        let playerLayer = AVPlayerLayer(player: self.player)
        return playerLayer
    }()
    
    lazy var player: AVPlayer = {
        let player = AVPlayer(playerItem: self.playerItem)
        return player
    }()
    
    lazy var playerItem: AVPlayerItem = {
        let playerItem = AVPlayerItem(url: self.url!)
        return playerItem
    }()
    
    // MARK: 监听通知：播放结束、异常中断、进入后台、进入前天
    fileprivate func _addNotificationCenter() {
        // 添加视频播放结束通知
        NotificationCenter.default.addObserver(self, selector: #selector(didPlayToEndTimeNotification), name: Notification.Name.AVPlayerItemDidPlayToEndTime, object: playerItem)
        // 添加视频异常中断通知
        NotificationCenter.default.addObserver(self, selector: #selector(playbackStalledNotification), name: Notification.Name.AVPlayerItemPlaybackStalled, object: playerItem)
        // 添加程序将要进入后台通知
        NotificationCenter.default.addObserver(self, selector: #selector(willEnterBcakgroundNotification), name: UIApplication.willResignActiveNotification, object: nil)
        // 添加程序已经返回前台通知
        NotificationCenter.default.addObserver(self, selector: #selector(didEnterPlayGroundNotification), name: UIApplication.didBecomeActiveNotification, object: nil)
    }
    
    // 移除通知中心
    fileprivate func _removeNotificationCenter() {
        NotificationCenter.default.removeObserver(self, name: Notification.Name.AVPlayerItemDidPlayToEndTime, object: playerItem)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.AVPlayerItemPlaybackStalled, object: playerItem)
        NotificationCenter.default.removeObserver(self, name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIApplication.didBecomeActiveNotification, object: nil)
    }
    
    // 播放结束
    @objc func didPlayToEndTimeNotification() {
        displayLinkHandler(playerItem.currentTime(), CMTime(), .play)
        displayLink.invalidate()
        
        playFinished()
    }
    // 播放异常
    @objc func playbackStalledNotification() {
        
    }
    // 播放进入后台
    @objc func willEnterBcakgroundNotification() {
        player.pause()
        displayLinkHandler(playerItem.currentTime(), CMTime(), .pause)
    }
    // 播放返回前台
    @objc func didEnterPlayGroundNotification() {
        // 需要手动播放
    }
    
    // MARK: 监听事件
    // 添加观察者
    fileprivate func _addObserver() {
        // 观察播放状态
        playerItem.addObserver(self, forKeyPath: kPath_status, options: .new, context: nil)
        // 观察加载完毕的时间范围
        playerItem.addObserver(self, forKeyPath: kPath_loadedTimeRanges, options: .new, context: nil)
        // seekToTime后，缓冲数据为空，而且有效时间内数据无法补充，播放失败
        playerItem.addObserver(self, forKeyPath: kPath_playbackBufferEmpty, options: .new, context: nil)
        //seekToTime后, 可以正常播放，相当于readyToPlay，一般拖动滑竿菊花转，到了这个这个状态菊花隐藏
        playerItem.addObserver(self, forKeyPath: kPath_playbackLikelyToKeepUp, options: .new, context: nil)
        
        isAddObserver = true
    }
    
    // 移除监听
    fileprivate func _removeObserve() {
        if isAddObserver {
            playerItem.removeObserver(self, forKeyPath: kPath_status, context: nil)
            playerItem.removeObserver(self, forKeyPath: kPath_loadedTimeRanges, context: nil)
            playerItem.removeObserver(self, forKeyPath: kPath_playbackBufferEmpty, context: nil)
            playerItem.removeObserver(self, forKeyPath: kPath_playbackLikelyToKeepUp, context: nil)
        }
    }
    
    override open func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        // 创建局部的PlayerItem
        let observePlayerItem = object as? AVPlayerItem
        
        switch keyPath! {
        case kPath_status:
            if observePlayerItem?.status == .readyToPlay {
                self.playerInfo(playerItem.duration, .readyToPlay)
            } else if observePlayerItem?.status == .failed {
                #if DEBUG
                print("获取播放内容出错！", observePlayerItem, change)
                #endif
                self.playerInfo(CMTime(seconds: 0, preferredTimescale: 0), .failed)
            } else {
                #if DEBUG
                print("未知错误")
                #endif
                self.playerInfo(CMTime(seconds: 0, preferredTimescale: 0), .unknown)
            }
            playerInfoState = (observePlayerItem?.status)!
        case kPath_loadedTimeRanges:
            // 播放器的缓存进度
            let loadedTimeRanges = observePlayerItem?.loadedTimeRanges
            let timeRange = loadedTimeRanges?.first?.timeRangeValue  // 获取缓冲区域
            cacheTime = (timeRange?.duration)!
            guard let duration = timeRange?.duration else {
                return
            }
            if duration.seconds < Double(2) {
                player.pause()
                displayLinkHandler(playerItem.currentTime(), CMTime(), .pause)
            }
            break
        case kPath_playbackBufferEmpty:
            // 播放缓冲区空
            #if DEBUG
            print("playbackBufferEmpty")
            #endif
            break
        case kPath_playbackLikelyToKeepUp:
            // 由于 AVPlayer 缓存不足就会自动暂停，所以缓存充足了需要手动播放，才能继续播放
            // 判断是否有缓冲数据
            #if DEBUG
            print("playbackLikelyToKeepUp")
            #endif
            if state == .pause {
                break
            }
            playerInfoState = .readyToPlay
            update(state: .play)
            break
        default:
            break
        }
    }
    
    public func update(state: YYPlayerState) {
        self.state = state
    }
    
    public var state: YYPlayerState! {
        didSet {
            switch state {
            case .play?:
                _play()
            case .pause?:
                _pause()
            case .stop?:
                _stop()
            case .finished?:
                break
            case .unknow?:
                _unknow()
            case .none:
                break
            }
        }
    }
    
    // 出错之后点击播放调起该方法
    // 无网时候进入视频播放界面 再次播放调用 此方法
    public func againLoadPlayerItem() {
        let url = self.url
        self.url = url
    }
    
    // 播放
    private func _play() {
        player.play()
        displayLink = CADisplayLink(target: self, selector: #selector(refreshProgress))
        displayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.default)
    }
    
    // 暂停
    private func _pause() {
        player.pause()
        displayLinkHandler(playerItem.currentTime(), CMTime(), .pause)
    }
    
    // 停止
    private func _stop() {
        playerItem.seek(to: CMTime.zero)
        update(state: .pause)
        _removeObserve()
        _removeNotificationCenter()
    }
    
    // 未知状态
    private func _unknow() {
        #if DEBUG
        print("更改状态时候发生未知错误")
        #endif
    }
    
    // 设置播放到哪个时间点
    public func seek(seconds: Double) {
        let time = CMTime(seconds: seconds, preferredTimescale: 260)
        player.seek(to: time)
    }
    
    // 实时刷新progress
    @objc private func refreshProgress() {
        displayLinkHandler(playerItem.currentTime(), CMTime(), .play)
    }
    
    // release
    public func releaseAll() {
        _stop()
    }
    
    deinit {
        #if DEBUG
        print("YYPlayer deinit")
        #endif
    }
}
